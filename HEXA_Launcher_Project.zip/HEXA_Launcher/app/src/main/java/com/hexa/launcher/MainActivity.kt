package com.hexa.launcher

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val voiceRequest = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        findViewById<Button>(R.id.voiceButton).setOnClickListener { listen() }
        findViewById<Button>(R.id.lockButton).setOnClickListener { lockScreen() }
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say: lock screen")
        startActivityForResult(i, voiceRequest)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.lowercase() ?: ""
            status.text = "Heard: $words"
            if (words.contains("lock") || words.contains("screen off") || words.contains("screen lock")) lockScreen()
        }
    }

    private fun lockScreen() {
        // Android requires a user-enabled Device Administrator/accessibility mechanism
        // for a third-party app to lock the screen. This demo opens the system security
        // flow rather than silently enabling privileged access.
        status.text = "Screen lock needs Android permission"
        Toast.makeText(this, "Enable the required device-lock permission in Android settings.", Toast.LENGTH_LONG).show()
    }
}

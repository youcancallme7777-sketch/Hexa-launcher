# HEXA Launcher
Starter Android Studio project for the HEXA custom launcher.

## Build
Open this folder in Android Studio, let Gradle sync, then Build > Build APK(s).

## Notes
The project registers HEXA as a HOME/launcher candidate and includes a voice-command UI.
Screen locking requires Android's privileged user-granted mechanism; the starter does not bypass Android security.
